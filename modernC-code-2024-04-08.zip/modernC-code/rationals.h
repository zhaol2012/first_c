#ifndef RATIONALS_H
# define RATIONALS_H 1
# include <stdbool.h>
# include "euclid.h"

typedef struct rat rat;

struct rat {
  bool sign;
  size_t num;
  size_t denom;
};

/* Functions that return a value of type rat. */
rat rat_get(signed sign, size_t num, size_t denom) [[__unsequenced__]];
rat rat_get_normal(rat x) [[__unsequenced__]];
rat rat_get_extended(rat x, size_t f) [[__unsequenced__]];
rat rat_get_prod(rat x, rat y) [[__unsequenced__]];
rat rat_get_sum(rat x, rat y) [[__unsequenced__]];


/* Functions that operate on pointers to rat. */
void rat_destroy(rat* rp) [[__unsequenced__]];
rat* rat_init(rat* rp,
              signed sign,
              size_t num, size_t denom) [[__unsequenced__]];
rat* rat_normalize(rat* rp) [[__unsequenced__]];
rat* rat_extend(rat* rp, size_t f) [[__unsequenced__]];
rat* rat_sumup(rat* rp, rat y) [[__unsequenced__]];
rat* rat_rma(rat* rp, rat x, rat y) [[__unsequenced__]];

/* Functions that are implemented as exercises. */
/** @brief Print @a x into @a tmp and return tmp. **/
char const* rat_print(size_t len, char tmp[len], rat const* x);
/** @brief Print @a x normalize and print. **/
char const* rat_normalize_print(size_t len, char tmp[len],
                                rat const* x);
rat* rat_dotproduct(rat rp[static 1], size_t n,
                    rat const A[n], rat const B[n]);

#endif
