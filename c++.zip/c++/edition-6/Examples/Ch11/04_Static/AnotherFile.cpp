import std;

void f();
//static void f();

void f()
{
	std::println("f");
}
