import std;

namespace
{
	void f();

	void f()
	{
		std::println("f");
	}
}
