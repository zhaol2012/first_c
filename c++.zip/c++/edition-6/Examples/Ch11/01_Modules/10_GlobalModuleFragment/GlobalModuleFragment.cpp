import person;

int main()
{
	Person p;
}