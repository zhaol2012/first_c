import std;

using namespace std;

int main()
{
	int i{ 3 };
	println("{}", (i > 2) ? "yes" : "no");
	println("{}", i > 2 ? "yes" : "no");
}
