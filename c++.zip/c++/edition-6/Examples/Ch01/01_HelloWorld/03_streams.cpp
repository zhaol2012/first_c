import std;

int main()
{
	std::cout << "There are " << 219 << " ways I love you." << std::endl;

	std::cout << std::format("There are {} ways I love you.", 219) << std::endl;

	return 0;
}
