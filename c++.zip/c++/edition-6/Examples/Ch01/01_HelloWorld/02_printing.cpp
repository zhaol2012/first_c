import std;

int main()
{
	std::println("Hello, World!");
	
	std::println("There are {} ways I love you.", 219);
	
	std::println("{} + {} = {}", 2, 4, 6);
	
	std::println(std::cerr, "Error: {}", 6);

	return 0;
}
