import std;

int main()
{
	int value;
	std::cin >> value;
	std::println("You entered {}", value);

	return 0;
}
