// 01_helloworld.cpp

import std;

int main()
{
	std::println("Hello, World!");
	return 0;
}
