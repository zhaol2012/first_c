import std;

using namespace std;

int main()
{
	string myString{ "Hello, World" };
	println("The value of myString is {}", myString);
	println("The second letter is {}", myString[1]);
}
