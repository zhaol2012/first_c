[[deprecated("Unsafe function, please use xyz")]] void func() {}

int main()
{
	func();
}