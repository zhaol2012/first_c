import std;

using namespace std;

int main()
{
	cout.put('a');
}
