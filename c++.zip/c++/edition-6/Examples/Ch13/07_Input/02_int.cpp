import std;

using namespace std;

int main()
{
	int userInput;
	cin >> userInput;
	println("User input was {}.", userInput);
}
