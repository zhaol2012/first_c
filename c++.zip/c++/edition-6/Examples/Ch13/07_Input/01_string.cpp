import std;

using namespace std;

int main()
{
	string userInput;
	cin >> userInput;
	println("User input was {}.", userInput);
}
