import std;

using namespace std;

int main()
{
	int i{ 7 };
	cout << i << endl;

	char ch{ 'a' };
	cout << ch << endl;

	string myString{ "Hello World." };
	cout << myString << endl;


	int j{ 11 };
	cout << "The value of j is " << j << "!" << endl;


	cout << "Line 1" << endl << "Line 2" << endl << "Line 3" << endl;
}
