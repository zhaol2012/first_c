import std;

using namespace std;

int main()
{
	vector<int> intVector; // Creates a vector of ints with zero elements
	println("Vector elements: {}", intVector);
}
