Note that SpreadsheetCellArrayNoDefault.cpp does not compile.


