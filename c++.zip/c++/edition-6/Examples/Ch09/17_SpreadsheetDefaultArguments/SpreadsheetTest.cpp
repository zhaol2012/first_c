import spreadsheet;

using namespace std;

int main()
{
	Spreadsheet s1;
	Spreadsheet s2 { 5 };
	Spreadsheet s3 { 5, 6 };
}
